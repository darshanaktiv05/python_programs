# Reverse the string:- string = "Hello World"
# OUTPUT: dlroW olleH

S1 = "Hello World"


print(S1[::-1])

# x = "".join(reversed(S1))
# print(x)
